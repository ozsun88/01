# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.audio import Audio  # noqa: E501
from swagger_server.models.audio_analysis import AudioAnalysis  # noqa: E501
from swagger_server.models.audio_download_token import AudioDownloadToken  # noqa: E501
from swagger_server.models.binary import Binary  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAudioController(BaseTestCase):
    """AudioController integration test stubs"""

    def test_create_audio(self):
        """Test case for create_audio

        Create a new audio.
        """
        data = dict(file=(BytesIO(b'some file data'), 'file.txt'),
                    name='name_example')
        response = self.client.open(
            '//audios',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_download_audio(self):
        """Test case for download_audio

        Download an audio data by id.
        """
        response = self.client.open(
            '//audios/{id}/download'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_download_audio_by_token(self):
        """Test case for download_audio_by_token

        Download an audio data by audio_download_token.
        """
        query_string = [('download_token', 'download_token_example')]
        response = self.client.open(
            '//audios/download_by_token',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_audio(self):
        """Test case for get_audio

        Get an audio by id.
        """
        response = self.client.open(
            '//audios/{id}'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_audio_analysis(self):
        """Test case for get_audio_analysis

        Get an audio analysis by id.
        """
        response = self.client.open(
            '//audios/{id}/analysis'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_audio_download_token(self):
        """Test case for get_audio_download_token

        Get an audio download token by id.
        """
        response = self.client.open(
            '//audios/{id}/download_token'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_audios(self):
        """Test case for list_audios

        Get all audios accessable.
        """
        response = self.client.open(
            '//audios',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
