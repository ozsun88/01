# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.payment_customer import PaymentCustomer  # noqa: E501
from swagger_server.test import BaseTestCase


class TestPaymentCustomerController(BaseTestCase):
    """PaymentCustomerController integration test stubs"""

    def test_get_default_payment_customer(self):
        """Test case for get_default_payment_customer

        Get a default payment customer.
        """
        response = self.client.open(
            '//payment_customers/default',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
