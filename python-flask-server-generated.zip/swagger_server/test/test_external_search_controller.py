# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.external_search_result import ExternalSearchResult  # noqa: E501
from swagger_server.test import BaseTestCase


class TestExternalSearchController(BaseTestCase):
    """ExternalSearchController integration test stubs"""

    def test_search_external(self):
        """Test case for search_external

        Search external music and get name, url, thumbnails, etc.
        """
        query_string = [('query', 'query_example'),
                        ('country', 'country_example')]
        response = self.client.open(
            '//external_search',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
