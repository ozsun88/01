# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.access_token import AccessToken  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAccessTokenController(BaseTestCase):
    """AccessTokenController integration test stubs"""

    def test_create_access_token(self):
        """Test case for create_access_token

        Create an API access token.
        """
        response = self.client.open(
            '//access_tokens',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
