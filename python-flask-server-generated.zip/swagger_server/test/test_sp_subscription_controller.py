# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.sp_subscription import SpSubscription  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSpSubscriptionController(BaseTestCase):
    """SpSubscriptionController integration test stubs"""

    def test_create_sp_subscription(self):
        """Test case for create_sp_subscription

        Create a new smartphone subscription.
        """
        data = dict(service='service_example',
                    receipt='receipt_example')
        response = self.client.open(
            '//sp_subscriptions',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_sp_subscriptions(self):
        """Test case for list_sp_subscriptions

        Get all accessable smartphone subscriptions.
        """
        response = self.client.open(
            '//sp_subscriptions',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
