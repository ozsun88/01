# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.payment import Payment  # noqa: E501
from swagger_server.test import BaseTestCase


class TestPaymentController(BaseTestCase):
    """PaymentController integration test stubs"""

    def test_create_payment(self):
        """Test case for create_payment

        Create a new payment.
        """
        data = dict(product_token='product_token_example',
                    service='service_example',
                    token='token_example')
        response = self.client.open(
            '//payments',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_execute_payment(self):
        """Test case for execute_payment

        Execute a payment by id.
        """
        data = dict(payer_id='payer_id_example')
        response = self.client.open(
            '//payments/{id}/execute'.format(id=2),
            method='PUT',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_payment(self):
        """Test case for get_payment

        Get a payment by id.
        """
        response = self.client.open(
            '//payments/{id}'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_payments(self):
        """Test case for list_payments

        Get all accessable payments.
        """
        response = self.client.open(
            '//payments',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
