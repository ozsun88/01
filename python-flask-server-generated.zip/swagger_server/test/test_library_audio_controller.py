# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.library_audio import LibraryAudio  # noqa: E501
from swagger_server.models.library_audio_analysis import LibraryAudioAnalysis  # noqa: E501
from swagger_server.models.library_audio_like import LibraryAudioLike  # noqa: E501
from swagger_server.test import BaseTestCase


class TestLibraryAudioController(BaseTestCase):
    """LibraryAudioController integration test stubs"""

    def test_create_library_audio(self):
        """Test case for create_library_audio

        Create a new library audio.
        """
        data = dict(file=(BytesIO(b'some file data'), 'file.txt'))
        response = self.client.open(
            '//library_audios',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_library_audio_like(self):
        """Test case for create_library_audio_like

        Create a new library audio like.
        """
        response = self.client.open(
            '//library_audios/{id}/like'.format(id=2),
            method='POST',
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_library_audio(self):
        """Test case for delete_library_audio

        Delete library audio.
        """
        response = self.client.open(
            '//library_audios/{id}'.format(id=2),
            method='DELETE',
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_library_audio(self):
        """Test case for get_library_audio

        Get a library audio by id.
        """
        response = self.client.open(
            '//library_audios/{id}'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_library_audio_analysis(self):
        """Test case for get_library_audio_analysis

        Get a library audio analysis by id.
        """
        response = self.client.open(
            '//library_audios/{id}/analysis'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_library_audios(self):
        """Test case for list_library_audios

        Get all library audios accessable.
        """
        response = self.client.open(
            '//library_audios',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_library_audio(self):
        """Test case for update_library_audio

        Update library audio.
        """
        data = dict(is_public=true)
        response = self.client.open(
            '//library_audios/{id}'.format(id=2),
            method='PUT',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
