# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.mastering import Mastering  # noqa: E501
from swagger_server.test import BaseTestCase


class TestMasteringController(BaseTestCase):
    """MasteringController integration test stubs"""

    def test_cancel_mastering(self):
        """Test case for cancel_mastering

        Cancel a mastering by id.
        """
        response = self.client.open(
            '//masterings/{id}/cancel'.format(id=2),
            method='PUT')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_mastering(self):
        """Test case for create_mastering

        Create a new mastering.
        """
        data = dict(mode='default',
                    input_audio_id=2,
                    bass_preservation=false,
                    mastering=false,
                    mastering_algorithm='v2',
                    noise_reduction=false,
                    preset='general',
                    target_loudness=-5,
                    target_loudness_mode='loudness',
                    mastering_matching_level=0,
                    mastering_reverb=false,
                    mastering_reverb_gain=-36,
                    reference_audio_id=2,
                    low_cut_freq=0,
                    high_cut_freq=0,
                    ceiling=0,
                    ceiling_mode='peak',
                    oversample=1,
                    sample_rate=44100,
                    bit_depth=16,
                    output_format='wav',
                    for_preview=false,
                    start_at=0,
                    end_at=-1,
                    video_title='')
        response = self.client.open(
            '//masterings',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_mastering(self):
        """Test case for delete_mastering

        Delete mastering.
        """
        response = self.client.open(
            '//masterings/{id}'.format(id=2),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_free_unlock_mastering(self):
        """Test case for free_unlock_mastering

        Free unlock a mastering by id.
        """
        response = self.client.open(
            '//masterings/{id}/free_unlock'.format(id=2),
            method='PUT')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_mastering(self):
        """Test case for get_mastering

        Get a mastering by id.
        """
        response = self.client.open(
            '//masterings/{id}'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_mastering_unlock_product(self):
        """Test case for get_mastering_unlock_product

        Review a mastering by id.
        """
        response = self.client.open(
            '//masterings/{id}/unlock_product'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_masterings(self):
        """Test case for list_masterings

        Get all accessable masterings.
        """
        response = self.client.open(
            '//masterings',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_publish_mastering(self):
        """Test case for publish_mastering

        Publish a mastering by id.
        """
        data = dict(service='service_example',
                    access_token='access_token_example',
                    access_token_secret='access_token_secret_example',
                    message='message_example')
        response = self.client.open(
            '//masterings/{id}/publish'.format(id=2),
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_review_mastering(self):
        """Test case for review_mastering

        Review a mastering by id.
        """
        data = dict(review_comment='review_comment_example',
                    review_score=0)
        response = self.client.open(
            '//masterings/{id}/review'.format(id=2),
            method='PUT',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_mastering(self):
        """Test case for update_mastering

        Update a mastering.
        """
        data = dict(preserved=true)
        response = self.client.open(
            '//masterings/{id}'.format(id=2),
            method='PUT',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
