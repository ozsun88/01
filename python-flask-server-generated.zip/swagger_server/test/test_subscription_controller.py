# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.subscription import Subscription  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSubscriptionController(BaseTestCase):
    """SubscriptionController integration test stubs"""

    def test_cancel_subscription(self):
        """Test case for cancel_subscription

        Cancel a subscription by id.
        """
        response = self.client.open(
            '//subscriptions/{id}/cancel'.format(id=2),
            method='PUT',
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_cancel_subscription_cancellation(self):
        """Test case for cancel_subscription_cancellation

        Cancel the subscription cancellation  by id.
        """
        response = self.client.open(
            '//subscriptions/{id}/cancel_cancellation'.format(id=2),
            method='PUT',
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_subscription(self):
        """Test case for create_subscription

        Create a new subscription.
        """
        data = dict(service='service_example',
                    stripe_plan_id='stripe_plan_id_example',
                    token='token_example',
                    affiliate_id='affiliate_id_example')
        response = self.client.open(
            '//subscriptions',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_subscription(self):
        """Test case for get_subscription

        Get a subscription by id.
        """
        response = self.client.open(
            '//subscriptions/{id}'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_subscriptions(self):
        """Test case for list_subscriptions

        Get all accessable subscriptions.
        """
        response = self.client.open(
            '//subscriptions',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
