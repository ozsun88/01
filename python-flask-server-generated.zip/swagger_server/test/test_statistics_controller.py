# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.anonymized_mastering import AnonymizedMastering  # noqa: E501
from swagger_server.models.group_buy_statistics import GroupBuyStatistics  # noqa: E501
from swagger_server.models.kpi import Kpi  # noqa: E501
from swagger_server.test import BaseTestCase


class TestStatisticsController(BaseTestCase):
    """StatisticsController integration test stubs"""

    def test_get_group_buy_statistics(self):
        """Test case for get_group_buy_statistics

        Get group buy statistics.
        """
        response = self.client.open(
            '//statistics/group_buy',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_anonymized_masterings(self):
        """Test case for list_anonymized_masterings

        Get anonymized masterings.
        """
        response = self.client.open(
            '//statistics/anonymized_masterings',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_kpis(self):
        """Test case for list_kpis

        Get KPIs.
        """
        response = self.client.open(
            '//statistics/kpis',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
