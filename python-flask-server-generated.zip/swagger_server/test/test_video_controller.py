# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.binary import Binary  # noqa: E501
from swagger_server.models.video import Video  # noqa: E501
from swagger_server.models.video_download_token import VideoDownloadToken  # noqa: E501
from swagger_server.test import BaseTestCase


class TestVideoController(BaseTestCase):
    """VideoController integration test stubs"""

    def test_download_video(self):
        """Test case for download_video

        Download an video data by id.
        """
        response = self.client.open(
            '//videos/{id}/download'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_download_video_by_token(self):
        """Test case for download_video_by_token

        Download an video data by video_download_token.
        """
        query_string = [('download_token', 'download_token_example')]
        response = self.client.open(
            '//videos/download_by_token',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_video(self):
        """Test case for get_video

        Get an video by id.
        """
        response = self.client.open(
            '//videos/{id}'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_video_download_token(self):
        """Test case for get_video_download_token

        Get an video download token by id.
        """
        response = self.client.open(
            '//videos/{id}/download_token'.format(id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_videos(self):
        """Test case for list_videos

        Get all videos accessable.
        """
        response = self.client.open(
            '//videos',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
