# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.user import User  # noqa: E501
from swagger_server.test import BaseTestCase


class TestUserController(BaseTestCase):
    """UserController integration test stubs"""

    def test_get_self(self):
        """Test case for get_self

        Get self user.
        """
        response = self.client.open(
            '//users/self',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_notify_registration(self):
        """Test case for notify_registration

        Notify user is registered.
        """
        data = dict(affiliate_id='affiliate_id_example',
                    referrer_url='referrer_url_example')
        response = self.client.open(
            '//users/self/notify_registration',
            method='PUT',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_send_invitation(self):
        """Test case for send_invitation

        Send invitation.
        """
        data = dict(invitee_email='invitee_email_example')
        response = self.client.open(
            '//users/self/send_invitation',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_self(self):
        """Test case for update_self

        Update self user.
        """
        data = dict(agreed_terms_of_service=true,
                    email='email_example')
        response = self.client.open(
            '//users/self',
            method='PUT',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
