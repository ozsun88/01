# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.amazon_subscription import AmazonSubscription  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAmazonSubscriptionController(BaseTestCase):
    """AmazonSubscriptionController integration test stubs"""

    def test_list_amazon_subscriptions(self):
        """Test case for list_amazon_subscriptions

        Get all accessable amazon subscriptions.
        """
        response = self.client.open(
            '//amazon_subscriptions',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
