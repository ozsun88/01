import connexion
import six

from swagger_server.models.binary import Binary  # noqa: E501
from swagger_server.models.video import Video  # noqa: E501
from swagger_server.models.video_download_token import VideoDownloadToken  # noqa: E501
from swagger_server import util


def download_video(id):  # noqa: E501
    """Download an video data by id.

     # noqa: E501

    :param id: Video id
    :type id: int

    :rtype: Binary
    """
    return 'do some magic!'


def download_video_by_token(download_token):  # noqa: E501
    """Download an video data by video_download_token.

     # noqa: E501

    :param download_token: Video download token
    :type download_token: str

    :rtype: Binary
    """
    return 'do some magic!'


def get_video(id):  # noqa: E501
    """Get an video by id.

     # noqa: E501

    :param id: Video id
    :type id: int

    :rtype: Video
    """
    return 'do some magic!'


def get_video_download_token(id):  # noqa: E501
    """Get an video download token by id.

     # noqa: E501

    :param id: Video id
    :type id: int

    :rtype: VideoDownloadToken
    """
    return 'do some magic!'


def list_videos():  # noqa: E501
    """Get all videos accessable.

     # noqa: E501


    :rtype: List[Video]
    """
    return 'do some magic!'
