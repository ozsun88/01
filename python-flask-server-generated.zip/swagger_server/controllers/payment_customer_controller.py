import connexion
import six

from swagger_server.models.payment_customer import PaymentCustomer  # noqa: E501
from swagger_server import util


def get_default_payment_customer():  # noqa: E501
    """Get a default payment customer.

     # noqa: E501


    :rtype: List[PaymentCustomer]
    """
    return 'do some magic!'
