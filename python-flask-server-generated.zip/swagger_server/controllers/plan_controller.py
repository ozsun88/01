import connexion
import six

from swagger_server.models.plan import Plan  # noqa: E501
from swagger_server import util


def list_plans():  # noqa: E501
    """Get all accessable plans.

     # noqa: E501


    :rtype: List[Plan]
    """
    return 'do some magic!'
