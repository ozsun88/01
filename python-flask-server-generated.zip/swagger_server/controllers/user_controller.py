import connexion
import six

from swagger_server.models.user import User  # noqa: E501
from swagger_server import util


def get_self():  # noqa: E501
    """Get self user.

     # noqa: E501


    :rtype: User
    """
    return 'do some magic!'


def notify_registration(affiliate_id=None, referrer_url=None):  # noqa: E501
    """Notify user is registered.

     # noqa: E501

    :param affiliate_id: The affiliate id of inviter.
    :type affiliate_id: str
    :param referrer_url: The referrer URL.
    :type referrer_url: str

    :rtype: User
    """
    return 'do some magic!'


def send_invitation(invitee_email):  # noqa: E501
    """Send invitation.

     # noqa: E501

    :param invitee_email: The email of invitee.
    :type invitee_email: str

    :rtype: User
    """
    return 'do some magic!'


def update_self(agreed_terms_of_service=None, email=None):  # noqa: E501
    """Update self user.

     # noqa: E501

    :param agreed_terms_of_service: Whether you agreed terms of service.
    :type agreed_terms_of_service: bool
    :param email: The email.
    :type email: str

    :rtype: User
    """
    return 'do some magic!'
