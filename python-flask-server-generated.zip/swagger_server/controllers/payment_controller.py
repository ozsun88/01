import connexion
import six

from swagger_server.models.payment import Payment  # noqa: E501
from swagger_server import util


def create_payment(product_token, service, token=None):  # noqa: E501
    """Create a new payment.

     # noqa: E501

    :param product_token: This parameter represents the product token.
    :type product_token: str
    :param service: This parameter represents the payment message.
    :type service: str
    :param token: This parameter represents the card token. This parameter is effective only when the service is \&quot;stripe\&quot;.
    :type token: str

    :rtype: Payment
    """
    return 'do some magic!'


def execute_payment(id, payer_id):  # noqa: E501
    """Execute a payment by id.

     # noqa: E501

    :param id: Payment id
    :type id: int
    :param payer_id: This parameter represents the card token. This parameter is effective only when the service is \&quot;paypal\&quot;.
    :type payer_id: str

    :rtype: Payment
    """
    return 'do some magic!'


def get_payment(id):  # noqa: E501
    """Get a payment by id.

     # noqa: E501

    :param id: Payment id
    :type id: int

    :rtype: Payment
    """
    return 'do some magic!'


def list_payments():  # noqa: E501
    """Get all accessable payments.

     # noqa: E501


    :rtype: List[Payment]
    """
    return 'do some magic!'
