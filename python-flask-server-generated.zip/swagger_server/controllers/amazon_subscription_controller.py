import connexion
import six

from swagger_server.models.amazon_subscription import AmazonSubscription  # noqa: E501
from swagger_server import util


def list_amazon_subscriptions():  # noqa: E501
    """Get all accessable amazon subscriptions.

     # noqa: E501


    :rtype: List[AmazonSubscription]
    """
    return 'do some magic!'
