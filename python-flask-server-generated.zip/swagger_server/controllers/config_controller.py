import connexion
import six

from swagger_server.models.config import Config  # noqa: E501
from swagger_server import util


def get_config():  # noqa: E501
    """Get config.

     # noqa: E501


    :rtype: Config
    """
    return 'do some magic!'
