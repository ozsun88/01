import connexion
import six

from swagger_server.models.mastering import Mastering  # noqa: E501
from swagger_server import util


def cancel_mastering(id):  # noqa: E501
    """Cancel a mastering by id.

     # noqa: E501

    :param id: Mastering id
    :type id: int

    :rtype: Mastering
    """
    return 'do some magic!'


def create_mastering(input_audio_id, mode=None, bass_preservation=None, mastering=None, mastering_algorithm=None, noise_reduction=None, preset=None, target_loudness=None, target_loudness_mode=None, mastering_matching_level=None, mastering_reverb=None, mastering_reverb_gain=None, reference_audio_id=None, low_cut_freq=None, high_cut_freq=None, ceiling=None, ceiling_mode=None, oversample=None, sample_rate=None, bit_depth=None, output_format=None, for_preview=None, start_at=None, end_at=None, video_title=None):  # noqa: E501
    """Create a new mastering.

     # noqa: E501

    :param input_audio_id: Input audio id
    :type input_audio_id: int
    :param mode: Mode
    :type mode: str
    :param bass_preservation: This parameter represents if the bass preservation is enabled.
    :type bass_preservation: bool
    :param mastering: This parameter represents if the mastering is enabled. This parameter is effective only when the mode is \&quot;default\&quot; or \&quot;custom\&quot;.
    :type mastering: bool
    :param mastering_algorithm: 
    :type mastering_algorithm: str
    :param noise_reduction: This parameter represents if the nosie reduction is enabled. This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type noise_reduction: bool
    :param preset: This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type preset: str
    :param target_loudness: This parameter represents the target loudness of the output audio in dB. This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type target_loudness: 
    :param target_loudness_mode: 
    :type target_loudness_mode: str
    :param mastering_matching_level: This parameter represents the mastering reference matching level. This parameter is effective only when the mode is \&quot;custom\&quot; and the mastering is enabled.
    :type mastering_matching_level: 
    :param mastering_reverb: This parameter represents if the mastering reverb is enabled. This parameter is effective only when the mode is \&quot;custom\&quot; and the mastering is enabled.
    :type mastering_reverb: bool
    :param mastering_reverb_gain: This parameter represents the mastering reverb gain relative to the dry sound in dB. This parameter is effective only when the mode is \&quot;custom\&quot; and the mastering is \&quot;true\&quot; and the mastering_reverb is \&quot;true\&quot;.
    :type mastering_reverb_gain: 
    :param reference_audio_id: Reference audio id. This parameter is effective only when the mode is \&quot;custom\&quot; and the mastering is enabled.
    :type reference_audio_id: int
    :param low_cut_freq: This parameter represents the low cut freq  of the output audio in Hz. This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type low_cut_freq: 
    :param high_cut_freq: This parameter represents the high cut freq of the output audio in Hz. This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type high_cut_freq: 
    :param ceiling: 
    :type ceiling: 
    :param ceiling_mode: 
    :type ceiling_mode: str
    :param oversample: 
    :type oversample: int
    :param sample_rate: This parameter represents the sample rate of the output audio in dB. This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type sample_rate: int
    :param bit_depth: This parameter represents the bit depth of the output audio in dB. This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type bit_depth: int
    :param output_format: This parameter represents the format of the output audio. This parameter is effective only when the mode is \&quot;custom\&quot;.
    :type output_format: str
    :param for_preview: If this is true, the mastering is treated for preview purpose (ex. not purchasable, not publishable, short lifetime). 
    :type for_preview: bool
    :param start_at: Partial mastering start at. 
    :type start_at: 
    :param end_at: Partial mastering end at. 
    :type end_at: 
    :param video_title: This parameter represents the title of output video.
    :type video_title: str

    :rtype: Mastering
    """
    return 'do some magic!'


def delete_mastering(id):  # noqa: E501
    """Delete mastering.

     # noqa: E501

    :param id: Mastering id
    :type id: int

    :rtype: Mastering
    """
    return 'do some magic!'


def free_unlock_mastering(id):  # noqa: E501
    """Free unlock a mastering by id.

     # noqa: E501

    :param id: Mastering id
    :type id: int

    :rtype: Mastering
    """
    return 'do some magic!'


def get_mastering(id):  # noqa: E501
    """Get a mastering by id.

     # noqa: E501

    :param id: Mastering id
    :type id: int

    :rtype: Mastering
    """
    return 'do some magic!'


def get_mastering_unlock_product(id):  # noqa: E501
    """Review a mastering by id.

     # noqa: E501

    :param id: Mastering id
    :type id: int

    :rtype: Mastering
    """
    return 'do some magic!'


def list_masterings():  # noqa: E501
    """Get all accessable masterings.

     # noqa: E501


    :rtype: List[Mastering]
    """
    return 'do some magic!'


def publish_mastering(id, access_token, message, service=None, access_token_secret=None):  # noqa: E501
    """Publish a mastering by id.

     # noqa: E501

    :param id: Mastering id
    :type id: int
    :param access_token: This parameter represents if the access token of the publishment service API.
    :type access_token: str
    :param message: This parameter represents the publishment message.
    :type message: str
    :param service: This parameter represents the publishment service.
    :type service: str
    :param access_token_secret: This parameter represents the access token secret of the publishment service API. This parameter is effective only when the service is \&quot;twitter\&quot;.
    :type access_token_secret: str

    :rtype: Mastering
    """
    return 'do some magic!'


def review_mastering(id, review_comment=None, review_score=None):  # noqa: E501
    """Review a mastering by id.

     # noqa: E501

    :param id: Mastering id
    :type id: int
    :param review_comment: This parameter represents the review comment.
    :type review_comment: str
    :param review_score: This parameter represents the review score.
    :type review_score: 

    :rtype: Mastering
    """
    return 'do some magic!'


def update_mastering(id, preserved=None):  # noqa: E501
    """Update a mastering.

     # noqa: E501

    :param id: Mastering id
    :type id: int
    :param preserved: Disable auto delete.
    :type preserved: bool

    :rtype: Mastering
    """
    return 'do some magic!'
