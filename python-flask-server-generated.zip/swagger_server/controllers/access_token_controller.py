import connexion
import six

from swagger_server.models.access_token import AccessToken  # noqa: E501
from swagger_server import util


def create_access_token():  # noqa: E501
    """Create an API access token.

     # noqa: E501


    :rtype: AccessToken
    """
    return 'do some magic!'
