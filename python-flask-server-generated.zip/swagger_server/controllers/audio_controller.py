import connexion
import six

from swagger_server.models.audio import Audio  # noqa: E501
from swagger_server.models.audio_analysis import AudioAnalysis  # noqa: E501
from swagger_server.models.audio_download_token import AudioDownloadToken  # noqa: E501
from swagger_server.models.binary import Binary  # noqa: E501
from swagger_server import util


def create_audio(file=None, name=None):  # noqa: E501
    """Create a new audio.

     # noqa: E501

    :param file: The file to upload.
    :type file: werkzeug.datastructures.FileStorage
    :param name: Audio name. If this is not specified, the name in file parameter is used.
    :type name: str

    :rtype: Audio
    """
    return 'do some magic!'


def download_audio(id):  # noqa: E501
    """Download an audio data by id.

     # noqa: E501

    :param id: Audio id
    :type id: int

    :rtype: Binary
    """
    return 'do some magic!'


def download_audio_by_token(download_token):  # noqa: E501
    """Download an audio data by audio_download_token.

     # noqa: E501

    :param download_token: Audio download token
    :type download_token: str

    :rtype: Binary
    """
    return 'do some magic!'


def get_audio(id):  # noqa: E501
    """Get an audio by id.

     # noqa: E501

    :param id: Audio id
    :type id: int

    :rtype: Audio
    """
    return 'do some magic!'


def get_audio_analysis(id):  # noqa: E501
    """Get an audio analysis by id.

     # noqa: E501

    :param id: Audio id
    :type id: int

    :rtype: AudioAnalysis
    """
    return 'do some magic!'


def get_audio_download_token(id):  # noqa: E501
    """Get an audio download token by id.

     # noqa: E501

    :param id: Audio id
    :type id: int

    :rtype: AudioDownloadToken
    """
    return 'do some magic!'


def list_audios():  # noqa: E501
    """Get all audios accessable.

     # noqa: E501


    :rtype: List[Audio]
    """
    return 'do some magic!'
