import connexion
import six

from swagger_server.models.sp_subscription import SpSubscription  # noqa: E501
from swagger_server import util


def create_sp_subscription(service, receipt=None):  # noqa: E501
    """Create a new smartphone subscription.

     # noqa: E501

    :param service: Service.
    :type service: str
    :param receipt: Base64 encoded app store receipt. This parameter is effective only when the service is \&quot;appstore\&quot;.
    :type receipt: str

    :rtype: SpSubscription
    """
    return 'do some magic!'


def list_sp_subscriptions():  # noqa: E501
    """Get all accessable smartphone subscriptions.

     # noqa: E501


    :rtype: List[SpSubscription]
    """
    return 'do some magic!'
