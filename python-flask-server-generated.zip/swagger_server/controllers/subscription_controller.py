import connexion
import six

from swagger_server.models.subscription import Subscription  # noqa: E501
from swagger_server import util


def cancel_subscription(id):  # noqa: E501
    """Cancel a subscription by id.

     # noqa: E501

    :param id: Subscription id
    :type id: int

    :rtype: Subscription
    """
    return 'do some magic!'


def cancel_subscription_cancellation(id):  # noqa: E501
    """Cancel the subscription cancellation  by id.

     # noqa: E501

    :param id: Subscription id
    :type id: int

    :rtype: Subscription
    """
    return 'do some magic!'


def create_subscription(service, stripe_plan_id=None, token=None, affiliate_id=None):  # noqa: E501
    """Create a new subscription.

     # noqa: E501

    :param service: This parameter represents the payment message.
    :type service: str
    :param stripe_plan_id: The Stripe plan id. This parameter is effective only when the service is \&quot;stripe\&quot;.
    :type stripe_plan_id: str
    :param token: This parameter represents the card token. This parameter is effective only when the service is \&quot;stripe\&quot;.
    :type token: str
    :param affiliate_id: Affiliate id of inviter user.
    :type affiliate_id: str

    :rtype: Subscription
    """
    return 'do some magic!'


def get_subscription(id):  # noqa: E501
    """Get a subscription by id.

     # noqa: E501

    :param id: Subscription id
    :type id: int

    :rtype: Subscription
    """
    return 'do some magic!'


def list_subscriptions():  # noqa: E501
    """Get all accessable subscriptions.

     # noqa: E501


    :rtype: List[Subscription]
    """
    return 'do some magic!'
