import connexion
import six

from swagger_server.models.anonymized_mastering import AnonymizedMastering  # noqa: E501
from swagger_server.models.group_buy_statistics import GroupBuyStatistics  # noqa: E501
from swagger_server.models.kpi import Kpi  # noqa: E501
from swagger_server import util


def get_group_buy_statistics():  # noqa: E501
    """Get group buy statistics.

     # noqa: E501


    :rtype: GroupBuyStatistics
    """
    return 'do some magic!'


def list_anonymized_masterings():  # noqa: E501
    """Get anonymized masterings.

     # noqa: E501


    :rtype: List[AnonymizedMastering]
    """
    return 'do some magic!'


def list_kpis():  # noqa: E501
    """Get KPIs.

     # noqa: E501


    :rtype: Kpi
    """
    return 'do some magic!'
