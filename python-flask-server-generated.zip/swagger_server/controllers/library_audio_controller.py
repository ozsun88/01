import connexion
import six

from swagger_server.models.library_audio import LibraryAudio  # noqa: E501
from swagger_server.models.library_audio_analysis import LibraryAudioAnalysis  # noqa: E501
from swagger_server.models.library_audio_like import LibraryAudioLike  # noqa: E501
from swagger_server import util


def create_library_audio(file=None):  # noqa: E501
    """Create a new library audio.

     # noqa: E501

    :param file: The file to upload.
    :type file: werkzeug.datastructures.FileStorage

    :rtype: LibraryAudio
    """
    return 'do some magic!'


def create_library_audio_like(id):  # noqa: E501
    """Create a new library audio like.

     # noqa: E501

    :param id: Library audio id
    :type id: int

    :rtype: LibraryAudioLike
    """
    return 'do some magic!'


def delete_library_audio(id):  # noqa: E501
    """Delete library audio.

     # noqa: E501

    :param id: Library audio id
    :type id: int

    :rtype: LibraryAudio
    """
    return 'do some magic!'


def get_library_audio(id):  # noqa: E501
    """Get a library audio by id.

     # noqa: E501

    :param id: Library audio id
    :type id: int

    :rtype: LibraryAudio
    """
    return 'do some magic!'


def get_library_audio_analysis(id):  # noqa: E501
    """Get a library audio analysis by id.

     # noqa: E501

    :param id: Library audio id
    :type id: int

    :rtype: LibraryAudioAnalysis
    """
    return 'do some magic!'


def list_library_audios():  # noqa: E501
    """Get all library audios accessable.

     # noqa: E501


    :rtype: List[LibraryAudio]
    """
    return 'do some magic!'


def update_library_audio(id, is_public=None):  # noqa: E501
    """Update library audio.

     # noqa: E501

    :param id: Library audio id
    :type id: int
    :param is_public: Whether the library audio is public.
    :type is_public: bool

    :rtype: LibraryAudio
    """
    return 'do some magic!'
