import connexion
import six

from swagger_server.models.external_search_result import ExternalSearchResult  # noqa: E501
from swagger_server import util


def search_external(query, country):  # noqa: E501
    """Search external music and get name, url, thumbnails, etc.

     # noqa: E501

    :param query: Search query
    :type query: str
    :param country: Country ex. US, JP, etc
    :type country: str

    :rtype: ExternalSearchResult
    """
    return 'do some magic!'
