# AiMasteringApi.Audio

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**fileResourceId** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**createdByUser** | **Boolean** |  | [optional] 
**status** | **String** |  | [optional] 
**failureReason** | **String** |  | [optional] 
**probeJson** | **String** |  | [optional] 
**rms** | **Number** |  | [optional] 
**peak** | **Number** |  | [optional] 
**truePeak** | **Number** |  | [optional] 
**lowpassTruePeak15khz** | **Number** |  | [optional] 
**loudness** | **Number** |  | [optional] 
**dynamics** | **Number** |  | [optional] 
**sharpness** | **Number** |  | [optional] 
**space** | **Number** |  | [optional] 
**loudnessRange** | **Number** |  | [optional] 
**drr** | **Number** |  | [optional] 
**soundQuality** | **Number** |  | [optional] 
**soundQuality2** | **Number** |  | [optional] 
**dissonance** | **Number** |  | [optional] 
**frames** | **Number** |  | [optional] 
**sampleRate** | **Number** |  | [optional] 
**channels** | **Number** |  | [optional] 
**createdAt** | **Date** |  | [optional] 
**updatedAt** | **Date** |  | [optional] 


