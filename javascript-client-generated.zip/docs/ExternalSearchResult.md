# AiMasteringApi.ExternalSearchResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itunes** | **[Object]** |  | [optional] 
**youtube** | **[Object]** |  | [optional] 


