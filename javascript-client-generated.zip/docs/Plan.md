# AiMasteringApi.Plan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | [optional] 
**currency** | **String** |  | [optional] 
**interval** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**stripePlanId** | **String** |  | [optional] 


<a name="CurrencyEnum"></a>
## Enum: CurrencyEnum


* `jpy` (value: `"jpy"`)

* `usd` (value: `"usd"`)




<a name="IntervalEnum"></a>
## Enum: IntervalEnum


* `month` (value: `"month"`)




