# AiMasteringApi.Payment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**service** | **String** |  | [optional] 
**productGiven** | **Boolean** |  | [optional] 
**product** | **Object** |  | [optional] 
**transactionId** | **String** |  | [optional] 
**transactionDetail** | **Object** |  | [optional] 
**createdAt** | **Date** |  | [optional] 


<a name="ServiceEnum"></a>
## Enum: ServiceEnum


* `paypal` (value: `"paypal"`)

* `stripe` (value: `"stripe"`)




