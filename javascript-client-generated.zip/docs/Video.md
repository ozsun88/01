# AiMasteringApi.Video

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**fileResourceId** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**createdAt** | **Date** |  | [optional] 
**updatedAt** | **Date** |  | [optional] 


