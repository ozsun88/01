# AiMasteringApi.GroupBuyStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**premiumPlanSubscribedUserCount** | **Number** |  | [optional] 


