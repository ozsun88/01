# AiMasteringApi.Kpi

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


