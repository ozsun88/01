# AiMasteringApi.JWT

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


