# AiMasteringApi.AccessToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessToken** | [**JWT**](JWT.md) |  | [optional] 


