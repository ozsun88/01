# AiMasteringApi.LibraryAudioLike

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Audio analysis id | [optional] 
**libraryAudioId** | **Number** | Audio id | [optional] 
**userId** | **Number** | User id | [optional] 


