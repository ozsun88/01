# AiMasteringApi.AudioAnalysis

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Audio analysis id | [optional] 
**audioId** | **Number** | Audio id | [optional] 
**analysis** | **Object** | Audio analysis data. The schema changes frequently. | [optional] 


