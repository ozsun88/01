# AiMasteringApi.Config

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auth0** | **Object** |  | [optional] 
**paypal** | **Object** |  | [optional] 
**stripe** | **Object** |  | [optional] 
**version** | **Object** |  | [optional] 


