# AiMasteringApi.AudioDownloadToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**downloadToken** | [**JWT**](JWT.md) |  | [optional] 
**downloadUrl** | **String** |  | [optional] 


